<meta http-equiv="Content-Type" content="text/html charset=utf8_unicode_ci;" />
<form name="form" method="post" action="account_regist_fin.php">
Account:<input type="text" name="id" /> <br>
password:<input type="password" name="pw" /> <br>
Password again:<input type="password" name="pw2" /> <br>
<input type="submit" name="button" value="Commit" />
</form>