<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html charset=utf8_unicode_ci;" />
<?php
//�Nsession�M��
unset($_SESSION['username']);
echo '�n�X��......';
echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
?>